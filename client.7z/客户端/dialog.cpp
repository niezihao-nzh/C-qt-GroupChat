#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    socket = new QTcpSocket(this);
    connect(ui->pushButtonConnect,SIGNAL(clicked()),this,SLOT(btnConnectCliekedSlot()));
    connect(ui->pushButtonSend,SIGNAL(clicked()),this,SLOT(btnSendClickedSlot()));
    connect(socket,SIGNAL(connected()), this,SLOT(connectedSlot()));

    connect(socket,SIGNAL(disconnected()),this,SLOT(disConnectedSlot()));
    connect(socket,SIGNAL(readyRead()),this,SLOT(readyReadSlot()));
    // -------------------------- 绑定同步按钮信号 --------------------------
      connect(ui->pushButtonSyncHistory, SIGNAL(clicked()), this, SLOT(btnSyncHistoryClickedSlot()));
      // 初始时同步按钮禁用
      ui->pushButtonSyncHistory->setEnabled(false);
}

Dialog::~Dialog()
{
    delete ui;
}

void Dialog::btnConnectCliekedSlot()
{
    QString ip=ui->lineEditIp->text();
    int port=ui->lineEditPort->text().toInt();
    socket->connectToHost(ip,port);
}

void Dialog::btnSendClickedSlot()
{
    QString text = ui->lineEditSend->text();
        if(text == "")
        {
            QMessageBox::warning(this,"提示","请输入发送内容");
            return;
        }
        text.prepend(QString::number(socket->localPort())+" :  ");
    QByteArray buffer=text.toUtf8();
    socket->write(buffer);

}

void Dialog::connectedSlot()
{
    ui->pushButtonConnect->setEnabled(false);
    ui->pushButtonConnect->setText("connected");
    ui->pushButtonSend->setEnabled(true);
    QMessageBox::information(this,"info","successfully connected");
    // -------------------------- 启用同步按钮 --------------------------
        ui->pushButtonSyncHistory->setEnabled(true);
}
void Dialog::disConnectedSlot()
{
    ui->pushButtonConnect->setEnabled(true);
    ui->pushButtonConnect->setText("connect");

    // 屏蔽连接按钮
    ui->pushButtonSend->setEnabled(false);
    // -------------------------- 禁用同步按钮 --------------------------
    ui->pushButtonSyncHistory->setEnabled(false);
}
void Dialog::readyReadSlot()
{
    QByteArray buffer=socket->readAll();

    //------------------------------------------------------------------
    QString recvData = QString::fromUtf8(buffer);

    if (recvData.startsWith("#HISTORY_DATA#"))
    {
            // 1. 截取有效数据，去掉开头标识 #HISTORY_DATA#
            QString historyData = recvData.remove(0, QString("#HISTORY_DATA#").length());
            // 2. 按分隔符 #SEP# 拆分多条记录
            QStringList historyList = historyData.split("#SEP#", QString::SkipEmptyParts);

            // 3. 清空现有聊天记录
            ui->textBrowser_room->clear();
            ui->textBrowser_room->append("=== Chat History ===");

            // 4. 遍历显示每条历史记录
            foreach (QString record, historyList) {
                // 按“|”拆分时间和消息
                QStringList timeAndMsg = record.split("|", QString::SkipEmptyParts);
                if (timeAndMsg.size() == 2) {
                    QString time = timeAndMsg[0];
                    QString msg = timeAndMsg[1];
                    // 显示格式：时间 + 消息
                    QString localPortStr = QString::number(socket->localPort());
                    if (msg.startsWith(localPortStr + ":  "))
                    {
                        msg += " (me)";
                    }
                    ui->textBrowser_room->append(QString("%1  %2").arg(time).arg(msg));
                }
            }
            ui->textBrowser_room->append("=== History Sync Completed ===");
            return; // 终止后续普通消息处理逻辑,很重要
        }
   //-----------------------------------------------------------------
    if((QString::number(socket->localPort())+" :  "+ ui->lineEditSend->text())==buffer)
    {
        buffer.append("(me)");//标明自己发送的消息
    }
    ui->textBrowser_room->append(buffer);
    QDateTime dt=QDateTime::currentDateTime();
    ui->textBrowser_room->append(dt.toString("yy-MM-dd  hh:mm:ss"));
}

void Dialog::btnSyncHistoryClickedSlot()
{
    if (socket->state()!=QTcpSocket::ConnectedState)
    {
        QMessageBox::warning(this, "提示", "请先连接服务器！");
                return;
    }
    // 发送查询标识：与服务器约定的 #QUERY_HISTORY#
        socket->write("#QUERY_HISTORY#");
        ui->textBrowser_room->append("Loading chat history...");
}

