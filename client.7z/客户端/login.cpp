#include "login.h"
#include "ui_login.h"
#include"dialog.h"

Login::Login(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Login)
{
    ui->setupUi(this);
    settings=new QSettings("MyApp","LoginInfo");
    flag="a";
    btnGroup = new QButtonGroup(this);
    btnGroup->addButton(ui->pushButton_9);
    btnGroup->addButton(ui->pushButton_10);
    //     ui->lineEdit_3->setPlaceholderText("please enter username");
    //     ui->lineEdit_4->setPlaceholderText("please enter password");

    connect(ui->pushButton_8,SIGNAL(clicked()),this,SLOT(signUpSlot()));
    connect(ui->pushButton_6,SIGNAL(clicked()),this,SLOT(loginSlot()));
    connect(ui->checkBox_3,SIGNAL(toggled(bool)),this,SLOT(rememberSlot(bool)));

    connetDB();//连接数据库
    loadRememberedInfo();


    ui->myframe->setStyleSheet("QDialog#myframe { "
                               "background-image: url(qrc:/new/prefix2/adam-hornyak-t_jSrDW5xPw-unsplash.jpg); "
                               "background-repeat: no-repeat; "
                               "background-position: center; "
                               "}");
}

Login::~Login()
{
    if(db.isOpen())
    {
        db.close();
    }
    delete settings;
    delete ui;
}
void Login::loadRememberedInfo()
{
    // 读取配置中保存的状态
    bool isRemember = settings->value("remember", false).toBool();//第二个参数当key不存在时返回false
    if (isRemember) {
        // 显示到输入框
        ui->lineEdit_3->setText(settings->value("userId").toString());
        ui->lineEdit_4->setText(settings->value("userPw").toString());
        // 勾选"记住密码"复选框
        ui->checkBox_3->setChecked(true);
    }
}
void Login::loginSlot()
{
    QString inputId=ui->lineEdit_3->text();
    QString inputPw=ui->lineEdit_4->text();
    QSqlQuery query;
    QString sql="SELECT password FROM account WHERE id=?";//通过id查找密码
    query.prepare(sql);
    query.addBindValue(inputId);
    if(!query.exec())
    {
        QMessageBox::critical(this, "数据库错误", "查询失败：" + query.lastError().text());
        return;
    }
    if(query.next())//找到匹配的账号
    {
        QString Pw=query.value(0).toString();//value返回的是通用字段需要转换
        if (Pw == inputPw) { // 密码匹配
            qDebug() << "登陆成功";
            // 如果勾选了记住密码，登录成功后更新保存的信息（防止用户修改后未重新勾选）
            if (ui->checkBox_3->isChecked())
            {
                settings->setValue("userId", inputId);
                settings->setValue("userPw", inputPw);
                settings->sync();
            }
            this->hide();
            Dialog* w = new Dialog;
            w->show();
            myclear();
        }
        else
        { // 密码不匹配
            QMessageBox::warning(this, "提示", "密码错误");
            myclear();
        }
    }
    else
    { // 未找到账号
        QMessageBox::warning(this, "提示", "账号不存在，请先注册");
        myclear();
    }

}

void Login::signUpSlot()
{
    id=ui->lineEdit_3->text();
    pw=ui->lineEdit_4->text();
    insertData(id,pw);
    qDebug()<<"注册成功";
    myclear();
}

void Login::rememberSlot(bool checked)
{
    if(checked==true)
    {
        QString currentId = ui->lineEdit_3->text();
        QString currentPw = ui->lineEdit_4->text();
        settings->setValue("remember", true);
        settings->setValue("userId", currentId);
        settings->setValue("userPw", currentPw);
        flag="b";
    }
    else
    {
        // 取消勾选时清除配置
        settings->setValue("remember", false);
        settings->remove("userId");  // 删除保存的账号
        settings->remove("userPw");  // 删除保存的密码
        flag="a";
    }
    settings->sync();
}
void Login::myclear()
{
    if(flag=="a")
    {
        ui->lineEdit_3->clear();
        ui->lineEdit_4->clear();
    }
}

void Login::createTable()
{
    // sql语句
    QString sql = "CREATE TABLE account(id INTEGER PRIMARY KEY,password INTEGER);";

    // 创建数据库操作类
    QSqlQuery sq;

    if(sq.exec(sql))    // 表创建成功
    {
        qDebug() << "建表成功";
    }
    else    // 建表失败，注意：建表成功或者失败都很正常，如果要建立的表已经存在，就会建表失败
    {
        QSqlError errInfo = sq.lastError();
        QString text = errInfo.text();
        qDebug() << "建表失败:" << text;
    }

}

void Login::connetDB()
{
    // 获取数据库的连接对象
    db = QSqlDatabase::addDatabase("QSQLITE");
    // 设置数据库名称
    db.setDatabaseName("account_management.db");
    // 打开数据库连接
    bool ret = db.open();
    if(ret == true)
    {
        qDebug () << "打开成功";
        createTable();
    }
    else
    {
        // 数据库连接打开失败
        QSqlError errInfo = db.lastError();
        QString text = errInfo.text();
        QMessageBox::critical(this,"错误",text);
    }
}
void Login::insertData(QString id,QString pw)
{
    if(id== "")
    {
        QMessageBox::warning(this,"提示","请输入id");
        return;
    }

    if(pw == "")
    {
        QMessageBox::warning(this,"提示","请输入密码");
        return;
    }

    // 预处理的SQL语句
    QString sql = "INSERT INTO account VALUES(?,?)";

    // 预处理
    QSqlQuery sq;
    sq.prepare(sql);

    // 绑定参数
    sq.addBindValue(id);
    sq.addBindValue(pw);


    // 执行绑定后的SQL语句
    if(sq.exec())
    {
        QMessageBox::information(this,"通知","注册成功");
    }
    else // 失败
    {
        // 获取错误信息封装类
        QSqlError info = sq.lastError();
        QString text = info.text();
        QMessageBox::warning(this,"通知","数据插入失败");
        qDebug() << text;
    }
}

