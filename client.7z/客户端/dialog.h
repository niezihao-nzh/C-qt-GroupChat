#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include<QMessageBox>
#include<QTcpSocket>
#include<QDebug>
#include<QDateTime>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private:
    Ui::Dialog *ui;
    QTcpSocket *socket;

private slots:
    void btnConnectCliekedSlot();
    void btnSendClickedSlot();
    void connectedSlot();
    void disConnectedSlot();
    void readyReadSlot();
    void btnSyncHistoryClickedSlot();

};

#endif // DIALOG_H
