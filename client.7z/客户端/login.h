#ifndef LOGIN_H
#define LOGIN_H

#include <QDialog>
#include<QDebug>
#include<QButtonGroup>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>
#include <QSettings>
#include <QMessageBox>
namespace Ui {
class Login;
}

class Login : public QDialog
{
    Q_OBJECT

public:
    explicit Login(QWidget *parent = 0);
    ~Login();
    QString flag;


private:
    Ui::Login *ui;
    QButtonGroup *btnGroup;
    QString id;
    QString pw;
    void myclear();
    void createTable(); // 创建表
    QSqlDatabase db;    // 数据库连接对象
    QSettings *settings;//创建setting
     void connetDB();   // 连接到数据库
      void insertData(QString id,QString pw);
      void loadRememberedInfo();  // 加载记住的账号密码

private slots:
    void loginSlot();
    void signUpSlot();
    void rememberSlot(bool checked);
};

#endif // LOGIN_H
