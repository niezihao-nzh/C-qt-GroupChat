#ifndef DIALOG_H
#define DIALOG_H

#include <QDialog>
#include<QTcpServer>
#include<QTcpSocket>
#include<QMessageBox>
#include<QDebug>
#include <QSqlDatabase>
#include <QSqlError>
#include <QSqlQuery>

namespace Ui {
class Dialog;
}

class Dialog : public QDialog
{
    Q_OBJECT

public:
    explicit Dialog(QWidget *parent = 0);
    ~Dialog();

private:
    Ui::Dialog *ui;
    QTcpServer *server;
    QList<QTcpSocket*>sockets;
    QSqlDatabase db;
    void connectDB();
    void createTable(); // 创建表
    void insertData(QByteArray buffer);  // 添加数据
    void queryHistory(QTcpSocket*targetSocket);//向客户端返回历史记录

private slots:
     void newConnectionSlot();
     void disconnectSlot();
     void readyReadSlot();




};

#endif // DIALOG_H
