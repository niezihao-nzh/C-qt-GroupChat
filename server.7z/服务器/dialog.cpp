#include "dialog.h"
#include "ui_dialog.h"

Dialog::Dialog(QWidget *parent) :
    QDialog(parent),
    ui(new Ui::Dialog)
{
    ui->setupUi(this);
    server = new QTcpServer(this);

    // 开启监听
    bool result = server->listen(QHostAddress::Any,8887);
    if(!result)
    {
        ui->textBrowser->append("监听失败");
        return;
    }

    ui->textBrowser->append("监听开启成功，端口为：8887！！！");
    connect(server,SIGNAL(newConnection()),this,SLOT(newConnectionSlot()));
    connectDB();
}

Dialog::~Dialog()
{
    if(server->isListening()) server->close();
    if(db.isOpen()) db.close();  // 关闭数据库
    delete ui;
}

void Dialog::connectDB()
{
    db=QSqlDatabase::addDatabase("QSQLITE");
    db.setDatabaseName("chat_history.db");
    bool ret=db.open();
    if(ret == true)
    {
        qDebug () << "数据库打开成功";
        createTable();

    }
    else
    {
        // 数据库连接打开失败
        QSqlError errInfo = db.lastError();
        QString text = errInfo.text();
        QMessageBox::critical(this,"错误",text);
    }

}

void Dialog::createTable()
{
    // 表名统一为history，新增自增ID（主键）和时间字段
    QString sql = "CREATE TABLE IF NOT EXISTS history ("
                  "id INTEGER PRIMARY KEY AUTOINCREMENT, "  // 自增ID（唯一标识）
            "time DATETIME DEFAULT CURRENT_TIMESTAMP, "  // 自动记录时间
            "message TEXT);";  // 消息内容（允许重复）

    QSqlQuery sq;
    if(sq.exec(sql))
    {
        qDebug() << "建表成功（或表已存在）";
    }
    else
    {
        QSqlError errInfo = sq.lastError();
        qDebug() << "建表失败:" << errInfo.text();
    }
}

void Dialog::insertData(QByteArray buffer)
{
    QString message = QString::fromUtf8(buffer);  // 显式转码（避免中文乱码）

    // 表名改为history，明确指定插入的字段（time会自动生成，无需手动插入）
    QString sql = "INSERT INTO history (message) VALUES(?)";

    QSqlQuery sq;
    sq.prepare(sql);
    sq.addBindValue(message);  // 绑定消息内容

    if(sq.exec())
    {
        ui->textBrowser->append("数据插入成功");
    }
    else
    {
        QSqlError info = sq.lastError();
        ui->textBrowser->append("数据插入失败：" + info.text());
        qDebug() << "插入错误：" << info.text();
    }
}

void Dialog::queryHistory(QTcpSocket *targetSocket)
{
    if (!db.isOpen()) {
        ui->textBrowser->append("数据库未打开，无法查询历史记录");
        return;
    }

    // 1. 查询数据库：按时间顺序获取所有历史记录（id递增即时间递增）
    QString sql = "SELECT time, message FROM history ORDER BY id ASC";
    QSqlQuery sq;
    if (!sq.exec(sql))
    {
        ui->textBrowser->append("查询历史记录失败：" + sq.lastError().text());
        return;
    }

    // 2. 拼接历史记录：每条记录格式为“时间|消息内容”，多条用“#SEP#”分隔
    QString historyData;
    while (sq.next()) {
        QString time = sq.value("time").toString(); // 数据库中的时间字段
        QString msg = sq.value("message").toString(); // 数据库中的消息字段
        // 拼接单条记录（用“|”分隔时间和消息，避免与内容混淆）
        historyData += time + "|" + msg + "#SEP#";
    }

    // 3. 发送历史数据给客户端：开头加标识“#HISTORY_DATA#”，便于客户端识别
    QString sendData = "#HISTORY_DATA#" + historyData;
    targetSocket->write(sendData.toUtf8());
    ui->textBrowser->append("已向客户端返回历史记录");
}

void Dialog::newConnectionSlot()
{
    // 保存当前的Socket连接对象
    sockets.append( server->nextPendingConnection());

    connect(sockets.last(),SIGNAL(disconnected()), this,SLOT(disconnectSlot()));//处理断开
    connect(sockets.last(),SIGNAL(readyRead()),this,SLOT(readyReadSlot()));//读取数据
    // 获取客户端的IP地址
    QString ip = sockets.last()->peerAddress().toString();
    // 获取客户端的端口号
    quint16 port = sockets.last()->peerPort();

    // 字符串拼接
    ip.prepend("新连接来啦：").append(":").append(QString::number(port));
    ui->textBrowser->append(ip);

}
void Dialog::disconnectSlot()
{
    // 找到断开连接的客户端socket
    QTcpSocket *disconnectedSocket = qobject_cast<QTcpSocket*>(sender());
    if (disconnectedSocket && sockets.contains(disconnectedSocket))
    {
        // 获取断开连接的客户端信息
        QString ip = disconnectedSocket->peerAddress().toString();
        quint16 port = disconnectedSocket->peerPort();
        ip.prepend("老连接走了：").append(":").append(QString::number(port));
        ui->textBrowser->append(ip);

        // 从列表中移除并释放资源
        sockets.removeOne(disconnectedSocket);
        disconnectedSocket->deleteLater(); // 避免内存泄漏
    }
}

void Dialog::readyReadSlot()
{
    QTcpSocket *senderSocket = qobject_cast<QTcpSocket*>(sender());
    if (!senderSocket)
    { // 安全检查：确保是有效的socket
        return;
    }

    // 2. 读取该客户端发送的消息
    QByteArray buffer = senderSocket->readAll();
    if (buffer.isEmpty())
    { // 避免空消息
        return;
    }
    // -------------------------- 处理历史记录查询请求 ------------------
    QString recvData = QString::fromUtf8(buffer);
    if (recvData == "#QUERY_HISTORY#")
    {
        ui->textBrowser->append("收到客户端历史记录查询请求");
        queryHistory(senderSocket); // 向该客户端返回历史记录
        return; // 终止后续转发逻辑，避免把查询标识当作普通消息转发
    }
    // ----------------------------------------------------------------------
    for(int i=0;i<sockets.size();i++)
    {
        sockets.at(i)->write(buffer);
    }
    insertData(buffer);

}

